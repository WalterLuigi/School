#!/usr/bin/python

from nose.tools import *
import ex46

def setup():
    print("SETUP!")

def teardown():
    print("TEAR DOWN!")

def test_basic():
    print("I RAN!", end='')